import matplotlib.pyplot as plt
from keras import *
from keras.layers import *
class DeepANN():
    def simple_model(self,optimizer):
        model=Sequential()
        model.add(Flatten())
        model.add(Dense(120,activation="relu"))
        model.add(Dense(64,activation="relu"))
        model.add(Dense(2,activation="softmax"))

        model.compile(loss="categorical_crossentropy",optimizer="sgd",metrics=["accuracy"])
        return model


def train_model(model_instance, train_generator, validation_generator, epochs=10):

    history = model_instance.fit(
    train_generator,
    epochs=epochs,
    validation_data=validation_generator,
    verbose=1
    )
    return history


def compare_model(models, optimizers, train_generator, validation_generator, epochs=10):
    histories = []
    for model, optimizer in zip(models, optimizers):
        history = train_model(model, train_generator, validation_generator, epochs=10)
        histories.append(history)

    # Plot training and validation accuracy for each model
    plt.figure(figsize=(10, 6))
    for i, history in enumerate(histories):
        plt.plot(history.history['accuracy'], label=f'{optimizers[i]}')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.title('Model Comparison On Gender Dataset')
    plt.show(block=True)
import cv2
import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import  Optimizer_classification as cs
import preprocess as dp
if __name__=="__main__":
 images_folder_path='Emotion'
 imdata=dp.PreProcess_Data()
 retina_df, train, label = imdata.preprocess(images_folder_path)
 imdata.visualization_images(images_folder_path,2)
 tr_gen,tt_gen,va_gen=imdata.generate_train_test_images(train, label)
 Annmodel = cs.DeepANN()
 Model1 = Annmodel.simple_model()
 Ann_history = Model1.fit(tr_gen, epochs=2, validation_data=va_gen)
 Ann_test_loss, Ann_test_acc = Model1.evaluate(tr_gen)
 print(f'Test Accuarcy: {Ann_test_acc}')
 Model1.save('myModel.keras')
 print(Model1.summary())

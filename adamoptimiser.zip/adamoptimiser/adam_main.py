import os
import tensorflow as tf
from matplotlib import pyplot as plt
import cv2
import numpy as np
import preprocess as dp
import Optimizer_classification as cm

if __name__ == "__main__":
    images_folder_path = 'train'
    imdata = dp.preprocess()
    project_df, train, label = imdata.preprocess(images_folder_path)
    imdata.visualization_images(images_folder_path, 2)
    tr_gen, tt_gen, va_gen = imdata.generate_train_test_images(train, label)


    image_shape=(28,28,3)
    model_adam=cm.DeepANN.simple_model(image_shape,optimizer='adam')
    model_sgd = cm.DeepANN.simple_model(image_shape, optimizer='sgd')
    model_rmsprop = cm.DeepANN.simple_model(image_shape, optimizer='rmsprop')
    optimizers = ['adam', 'sgd', 'rmsprop']

    cm.compare_model([model_adam,model_sgd,model_rmsprop],optimizers,tr_gen,va_gen,tt_gen)
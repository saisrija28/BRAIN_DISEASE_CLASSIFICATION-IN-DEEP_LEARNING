import os
import tensorflow as tf
from matplotlib import pyplot as plt
import cv2
import numpy as np
import preprocess as dp
if __name__ == "__main__":
 images_folder_path = 'train'
 imdata = dp.PreProcess_Data()
 imdata.visualization_images(images_folder_path, 2)
 project_df, train, label = imdata.preprocess(images_folder_path)
 project_df.to_csv("project_images.csv")

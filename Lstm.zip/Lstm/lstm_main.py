import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import retina_processing as dp
import lstm_classification as lm

if __name__ == "__main__":
    images_folder_path = 'retina'
    imdata = dp.PreProcess_Data()
    retina_df, train, label = imdata.preprocess(images_folder_path)
    imdata.visualization_images(images_folder_path, 2)
    tr_gen, tt_gen, va_gen = imdata.generate_train_test_images(train, label)

    input_shape = (128, 128, 3)
    num_classes = 2
    lstm_Model = lm.DeepANN()
    m1 = lstm_Model.lstm_model(input_shape)
    lstm_history = m1.fit(tr_gen, epochs=2, validation_data=va_gen)

    # Plotting training and validation loss
    plt.figure(figsize=(10, 6))
    plt.plot(lstm_history.history['accuracy'], label='Training Accuracy')
    plt.plot(lstm_history.history['val_accuracy'], label='Validation Accuracy')
    plt.title('Training and Validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()


    LSTM_test_loss, LSTM_test_acc = m1.evaluate(tr_gen)
    print(f'Test Accuracy: {LSTM_test_acc}')
    m1.save('LSTMModel.keras')
    print(m1.summary())


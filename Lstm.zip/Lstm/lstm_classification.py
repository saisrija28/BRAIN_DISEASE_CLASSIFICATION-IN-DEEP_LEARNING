from keras.models import Sequential
from keras.layers import Dense, LSTM, Embedding, Reshape

class DeepANN:
    def lstm_model(self, input_shape):
        model = Sequential()
        model.add(Reshape((input_shape[0] * input_shape[1], input_shape[2]), input_shape=input_shape))
        model.add(LSTM(units=64, activation='relu'))
        model.add(Dense(units=2, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        return model

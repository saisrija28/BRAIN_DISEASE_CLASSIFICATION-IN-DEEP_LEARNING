from keras import *
from keras.layers import *
from keras.src.applications import VGG16, ResNet50


class DeepANN:
    def cnnreg_model(self):
        model = Sequential()
        input_shape=(28, 28,3)
        model.add(Conv2D(32, kernel_size=(3, 3), activation="relu", input_shape= input_shape, kernel_regularizer=regularizers.l1(0.01),
                         bias_regularizer = regularizers.l1(0.01)))
        model.add(MaxPooling2D(input_shape=(5, 5)))
        model.add(Dropout(0.25))
        model.add(BatchNormalization())
        model.add(Conv2D(64, kernel_size=(3, 3), activation="relu", input_shape= input_shape, kernel_regularizer=regularizers.l1(0.01),
                         bias_regularizer = regularizers.l1(0.01)))
        model.add(MaxPooling2D((2, 2)))
        model.add(Dropout(0.25))
        model.add(Flatten())
        model.add(Dense(256, activation="relu" , kernel_regularizer=regularizers.l1(0.010), activity_regularizer=regularizers.l2(0.01)))
        #model.add(Dense(64, activation="relu"))
        model.add(Dense(5,activation="softmax", kernel_regularizer=regularizers.l1(0.010), activity_regularizer=regularizers.l2(0.01)))
        model.compile(loss='categorical_crossentropy',optimizer='sgd',metrics=['accuracy'])

        return model

    def cnn_model(self):
        model = Sequential()
        model.add(Conv2D(32, (3, 3), activation="relu", input_shape=(28, 28, 3)))
        model.add(MaxPooling2D((2, 2)))
        model.add(BatchNormalization())
        model.add(Conv2D(64, (3, 3), activation="relu"))
        model.add(MaxPooling2D((2, 2)))

        model.add(Flatten())
        model.add(Dense(128, activation="relu"))
        model.add(Dense(64, activation="relu"))
        model.add(Dense(2, activation="softmax"))
        model.compile(loss='categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])
        return model

    def simple_model(self,optimizer):
        model=Sequential()
        model.add(Flatten())
        model.add(Dense(120,activation="relu"))
        model.add(Dense(64,activation="relu"))
        model.add(Dense(2,activation="softmax"))

        model.compile(loss="categorical_crossentropy",optimizer="sgd",metrics=["accuracy"])
        return model

    def vgg_model(self):
        model = Sequential()

        # First block
        model.add(Conv2D(64, (3, 3), activation='relu', padding='same', input_shape=(32, 32, 3)))
        model.add(Conv2D(64, (3, 3), activation='relu', padding='same'))
        model.add(MaxPooling2D((2, 2)))

        # Second block
        model.add(Conv2D(128, (3, 3), activation='relu', padding='same'))
        model.add(Conv2D(128, (3, 3), activation='relu', padding='same'))
        model.add(MaxPooling2D((2, 2)))

        # Third block
        model.add(Conv2D(256, (3, 3), activation='relu', padding='same'))
        model.add(Conv2D(256, (3, 3), activation='relu', padding='same'))
        model.add(MaxPooling2D((2, 2)))

        # Flatten and fully connected layers
        model.add(Flatten())
        model.add(Dense(512, activation='relu'))
        model.add(Dense(256, activation='relu'))
        model.add(Dense(4, activation='softmax'))  # Assuming binary classification

        # Compile the model
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

        return model

    def cnn_resnet(self):
        model = Sequential()
        model.add(ResNet50(weights='imagenet', include_top=False, input_shape=(32, 32, 3)))
        model.add(Flatten())
        model.add(Dense(1024, activation='relu'))
        model.add(Dense(512, activation='relu'))
        model.add(Dense(256, activation='relu'))
        model.add(Dense(128, activation='relu'))
        model.add(Dense(2, activation='softmax'))
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        return model

        # Create an instance of your class
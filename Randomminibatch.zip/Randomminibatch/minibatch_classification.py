import matplotlib.pyplot as plt
from keras import *
from keras.layers import *
class DeepANN():
    def simple_model(self,optimizer):
        model=Sequential()
        model.add(Flatten())
        model.add(Dense(120,activation="relu"))
        model.add(Dense(64,activation="relu"))
        model.add(Dense(2,activation="softmax"))

        model.compile(loss="categorical_crossentropy",optimizer="sgd",metrics=["accuracy"])
        return model


def train_model(model_instance, train_generator, validation_generator, epochs=5):

    history = model_instance.fit(
    train_generator,
    epochs=epochs,
    validation_data=validation_generator,
    verbose=1
    )
    return history

def compare_model(models, train_generator, validation_generator, epochs=5):
        histories = []
        for model in models:
            history = train_model(model, train_generator, validation_generator, epochs=epochs)
            histories.append(history)

        # Plot training and validation accuracy for each model
        plt.figure(figsize=(10, 6))
        for i, history in enumerate(histories):
            plt.plot(history.history['accuracy'], label=f'Model {i + 1}')
        plt.xlabel('Epochs')
        plt.ylabel('Accuracy')
        plt.legend()
        plt.title('Model Comparison')
        plt.show(block=True)

    #     # Evaluate each model on the test set
    # for i, model in enumerate(models):
    #     test_loss, test_acc = model.evaluate(test_generator)
    #     print(f"Model {i + 1} Test Loss: {test_loss:.4f}, Test Accuracy: {test_acc:.4f}")
import cv2
import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from keras.src.utils import to_categorical

import preprocess as dp
import minibatch_classification as cm


def preprocess_images(images, target_size=(28, 28)):
    processed_images = []
    for img_path in images:
        img = cv2.imread(img_path)
        if img is None:
            print(f"Warning: Unable to read image - {img_path}")
            continue

        img = cv2.resize(img, target_size)
        img = img / 255.0
        processed_images.append(img)
    return np.array(processed_images)


def random_mini_batch(X, Y, mini_batch_size=64, seed=None):
    if seed is not None:
        np.random.seed(seed)
    m = X.shape[0] if len(X.shape) > 1 else len(X)
    mini_batches = []
    permutation = list(np.random.permutation(m))
    shuffled_X = X[permutation, ...]
    shuffled_Y = Y[permutation, ...]

    num_complete_minibatches = m // mini_batch_size
    for k in range(0, num_complete_minibatches):
        start_idx = k * mini_batch_size
        end_idx = (k + 1) * mini_batch_size
        mini_batch_X = shuffled_X[start_idx:end_idx, ...]
        mini_batch_Y = shuffled_Y[start_idx:end_idx, ...]
        mini_batch = (mini_batch_X, mini_batch_Y)
        mini_batches.append(mini_batch)

    if m % mini_batch_size != 0:
        start_idx=num_complete_minibatches*mini_batch_size
        end_idx=start_idx+mini_batch_size
        mini_batch_X = shuffled_X[start_idx:end_idx, ...]
        mini_batch_Y = shuffled_Y[start_idx:end_idx, ...]
        mini_batch = (mini_batch_X, mini_batch_Y)
        mini_batches.append(mini_batch)

    return mini_batches

def one_hot_encode(labels):
    unique_labels=list(set(labels))
    label_dict={label: i for i, label in enumerate(unique_labels)}
    numeric_labels=[label_dict[label] for label in labels]
    one_hot_labels = to_categorical(numeric_labels)  # Pass num_classes to to_categorical
    return one_hot_labels

if __name__ == "__main__":
    images_folder_path = 'test'
    imdata = dp.PreProcess_Data()
    retina_df, train, label = imdata.preprocess(images_folder_path)
    imdata.visualization_images(images_folder_path, 2)
    tr_gen, tt_gen, va_gen = imdata.generate_train_test_images(train, label)

    # Debugging to identify problematic image
    problematic_images = []
    for img_path in train:
        img = cv2.imread(img_path)
        if img is None:
            problematic_images.append(img_path)

    print("Problematic images:", problematic_images)

    X_train_images = preprocess_images(train)
    Y_train = label
    Y_train_numeric = one_hot_encode(Y_train)

    mini_batches = random_mini_batch(X_train_images, Y_train_numeric, mini_batch_size=64, seed=42)
    for mini_batch_X, mini_batch_Y in mini_batches:
        print("Mini-batch X shape:", mini_batch_X.shape)
        print("Mini-batch Y shape:", mini_batch_Y.shape)




    image_shape = (28, 28, 3)
    model_adam = cm.DeepANN.simple_model(image_shape, optimizer='adam')
    model_sgd = cm.DeepANN.simple_model(image_shape, optimizer='sgd')
    model_rmsprop = cm.DeepANN.simple_model(image_shape, optimizer='rmsprop')
    model_adamax = cm.DeepANN.simple_model(image_shape, optimizer='adamax')

    models = [model_adam, model_sgd, model_rmsprop, model_adamax]

    for model in models:
        model.fit(tr_gen, epochs=10, validation_data=va_gen)

    total_accuracy = 0.0
    for model in models:
        _, test_accuracy = model.evaluate(tt_gen)
        total_accuracy += test_accuracy
        average_accuracy = total_accuracy / len(models)
        print("Total accuracy:", average_accuracy)